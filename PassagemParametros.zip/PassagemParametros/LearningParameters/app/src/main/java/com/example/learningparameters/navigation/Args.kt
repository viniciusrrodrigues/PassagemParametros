package com.example.learningparameters.navigation

const val USER = "user"