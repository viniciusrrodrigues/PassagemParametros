  # [![Typing SVG](https://readme-typing-svg.herokuapp.com/?color=B89FF1&size=35&center=true&vCenter=true&width=1000&lines=App+para+aprender+parâmetros!;Desenvolvido+em+kotlin!)](https://git.io/typing-svg)

Foi desenvolvido um aplicativo com passagem de parâmetros .

 <a href="LearningParameters/app/src/main/java/com/example/learningparameters/MainActivity.kt" target="_blank"><img src="https://img.shields.io/badge/App-0D1117?style=for-the-badge&logo=android-studio&logoColor=EC869F"></a>

<img width="250" alt="image" src="https://github.com/user-attachments/assets/bf4ceeca-f66e-4a0b-a13b-fedb27558081" />
<img width="250" alt="image" src="https://github.com/user-attachments/assets/5059e6f0-2a4a-48b4-8aec-f332720900d4" />

##

- Na view do Android Studio
<img width="800" alt="image" src="https://github.com/user-attachments/assets/e1022e78-cea4-438f-a62e-bb959453fe6d" />
